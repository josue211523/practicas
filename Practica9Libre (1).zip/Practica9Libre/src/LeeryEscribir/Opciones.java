/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeeryEscribir;
/**
 *
 * @author Gloria
 */
public class Opciones {
    
    public String leer;
    public String escribir;

    public Opciones(String leer, String escribir) {
        this.leer = leer;
        this.escribir = escribir;
    }

    public void imprimir() {
        System.out.println(this.leer);
    }
    public void teclar(){
        System.out.println(this.escribir);
    }
}
