
package pract10;

import java.util.Scanner;

public class Lector {
    public String leerCadena(){
        Scanner in = new Scanner(System.in);
        return in.nextLine();
    }
   
    public int leerNumero(){
        Scanner in = new Scanner(System.in);
        return in.nextInt();
    }
}
