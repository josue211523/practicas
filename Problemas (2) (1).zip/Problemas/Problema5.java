package problema5;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Problema5 {
    public static void main(String[] args) {
      String frase;
      Scanner entrada = new Scanner(System.in);
      StringTokenizer cuenta;
      int contador;
        System.out.println("Introduzca la frase");
        frase=entrada.nextLine().trim();
        cuenta=new StringTokenizer(frase);
        System.out.println("Las palabras de la frase es:"+cuenta.countTokens());
        for(int c=0;c<frase.length();c++){
            if((frase.charAt(c)==' ')&&(frase.charAt(c+1)!=' ')){palabras++;}
        }
      
      
    }
    
}
