package problema7;
public class Problema7 {

    public static void main(String[] args) {
      String cadena = "Java es un leguaje que llevamos en el semestre";
      char []invertir=cadena.toCharArray();
      int cont;
      for(cont=cadena.length()-1;cont>=0;cont--){
          System.out.print(""+invertir[cont]);
      }
      
      
    }
    
}
