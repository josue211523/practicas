
package practica.pkg4;

public class Practica4 {

    public static void main(String[] args) {
        String lenguaje1 = "Java es Genial";
        String lenguaje3 = lenguaje1.toUpperCase();
        String lenguaje4 = lenguaje1.toLowerCase();
        System.out.println(lenguaje3 );
        System.out.println(lenguaje4 );
    }
    
}
