package problema.pkg6;
public class Problema6 {
    public static void main(String[] args) {
        String nombre = "josue carrizales nuñez";
        System.out.println(convertirAmayuscula(nombre));
        
    }
    public static String convertirAmayuscula(String parametro){
        String stg="";
        char letrauno= ' ';
        char c=' ';
        int aux=0;
        for(int i=0;i<parametro.length();i++){
            letrauno=parametro.charAt(0);
            c=parametro.charAt(i);
            if(letrauno==' '){
                stg="un nobre no puede empezar por espacios";
             
            }else if(!Character.isLetter(letrauno)){
                stg="Un nombre no puede empezar popr ningun tipo de caracter" +"que no sea una letra del alfabeto español"+letrauno;    
            }
            if(i==0){
                c=Character.toUpperCase(c);
            }
            if(i>=1){
                c=Character.toLowerCase(c);
            }
            if(c==' '){
                aux=(i+1);
            }
            if(aux==i){
                c=Character.toUpperCase(c);
            }
            stg+=c;
      }
        return stg;
    }
    
}
