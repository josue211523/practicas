package problema11;
public class Problema11 {
    public static void main(String[] args) {
        String palabra = "papel";
        System.out.println("¿La palabra " +palabra+ "es palindromo?" + esPalindromo(palabra));
        
    }
    public static  boolean esPalindromo(String palabra){
        palabra = palabra.toLowerCase();
        for (int i=0,k=palabra.length()-1;i<=k;i++,k--){
            if(palabra.charAt(i) != palabra.charAt(k)){
                return false;
            }
        }
        return true;
    }    
    
}
