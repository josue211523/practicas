package practica2;

public class Practica2 {

    public static void main(String[] args) {
      
        Pastoraleman pa = new Pastoraleman();
        System.out.println(pa.ladrar());
        System.out.println(pa.comer());
        System.out.println(pa.correr());
        System.out.println("");
        siames gto = new siames();
        System.out.println(gto.brincar());
        System.out.println(gto.comer());
        System.out.println(gto.dormir());
        System.out.println("");
        perico pe = new perico();
        System.out.println(pe.cantar());
        System.out.println(pe.comer());
        System.out.println(pe.volar());
    }
    
}
