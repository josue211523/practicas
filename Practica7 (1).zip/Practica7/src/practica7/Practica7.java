/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica7;


import java.util.ArrayList;
import java.util.Scanner;

public class Practica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        ArrayList<Automovil> listaAutomovil = new ArrayList<>(10);
        String alto;
        
        Automovil a1 = new Automovil();
                    System.out.println("Ingrese marca del automovil:");
                    a1.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a1.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a1.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a1.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a1.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a1.encender());
                    System.out.println(a1.getAlto());
                    System.out.println(a1.avanzar());
                    System.out.println(a1.Vuelta());
                    
                    listaAutomovil.add(a1);
                    
        Automovil a2 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a2.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a2.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a2.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a2.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a2.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a2.encender());
                    System.out.println(a2.getAlto());
                    System.out.println(a2.avanzar());
                    System.out.println(a2.Vuelta());
                    
                    
                    listaAutomovil.add(a2);
                    
        Automovil a3 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a3.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a3.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a3.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a3.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a3.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a3.encender());
                    System.out.println(a3.getAlto());
                    System.out.println(a3.avanzar());
                    System.out.println(a3.Vuelta());
                    
                    listaAutomovil.add(a3);
                    
        Automovil a4 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a4.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a4.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a4.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a4.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a4.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a4.encender());
                    System.out.println(a4.getAlto());
                    System.out.println(a4.avanzar());
                    System.out.println(a4.Vuelta());
                    
                    listaAutomovil.add(a4);
        Automovil a5 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a5.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a5.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a5.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a5.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a5.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a5.encender());
                    System.out.println(a5.getAlto());
                    System.out.println(a5.avanzar());
                    System.out.println(a5.Vuelta());
                    
                    listaAutomovil.add(a5);
                    
        Automovil a6 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a6.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a6.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a6.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a6.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a6.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a6.encender());
                    System.out.println(a6.getAlto());
                    System.out.println(a6.avanzar());
                    System.out.println(a6.Vuelta());
                    
                    listaAutomovil.add(a6);
        Automovil a7 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a7.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a7.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a7.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a7.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a7.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a7.encender());
                    System.out.println(a7.getAlto());
                    System.out.println(a7.avanzar());
                    System.out.println(a7.Vuelta());
                    
                    listaAutomovil.add(a7);
                    
        Automovil a8 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a8.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a8.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a8.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a8.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a8.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a8.encender());
                    System.out.println(a8.getAlto());
                    System.out.println(a8.avanzar());
                    System.out.println(a8.Vuelta());
                    
                    listaAutomovil.add(a8);
                    
        Automovil a9 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a9.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a9.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a9.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a9.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a9.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a9.encender());
                    System.out.println(a9.getAlto());
                    System.out.println(a9.avanzar());
                    System.out.println(a9.Vuelta());
                    
                    listaAutomovil.add(a9);
                    
        Automovil a10 = new Automovil();
                    System.out.println("\nIngrese marca del automovil:");
                    a10.setMarca(entrada.nextLine());
                    System.out.println("Ingrese modelo del automovil: ");
                    a10.setModelo(entrada.nextLine());
                    System.out.println("Ingrese color del automovil: ");
                    a10.setColor(entrada.nextLine());
                    System.out.println("Ingrese precio: ");
                    a10.setPrecio(entrada.nextLine());
                    System.out.println("Litros de gasolina");
                    a10.setGasolina(Integer.parseInt(entrada.nextLine()));
                    System.out.println(a10.encender());
                    System.out.println(a10.getAlto());
                    System.out.println(a10.avanzar());
                    System.out.println(a10.Vuelta());
                    
                    listaAutomovil.add(a10);
    
                                 
        
        for(int i = 0; i < listaAutomovil.size(); i++){ 
                       System.out.println("Auto: " + (i + 1));
                       Automovil auto =  listaAutomovil.get(i); 
                       
                       System.out.println("Marca: " + auto.getMarca());
                       System.out.println("Modelo: " + auto.getModelo());
                       System.out.println("Color: " + auto.getColor());
                       System.out.println("Precio: " + auto.getPrecio());
                       System.out.println("Encender"+ auto.avanzar());
                       System.out.println("Vuelta: " + auto.vuelta());
        }
    }
}
            
    
