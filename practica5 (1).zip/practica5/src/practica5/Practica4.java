/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;


import java.util.Scanner;

public class Practica4 {

     public static void main(String[] args) {

        int opc = 0, opc2 = 0, indice = 0, idb,ind = 0;
        String nombreCompleto, email,dni, telefonoCelular, telefonoFijo, webSite, cuit, marca = null, precio = null, modelo = null, color = null;

        Scanner sc = new Scanner(System.in);
        Object agenda[] = new Object[50];

       
        System.out.println(" 1 - Agregar contacto");
        System.out.println(" 2 - Buscar contacto por ID");
        System.out.println(" 3 - Editar contacto");
        System.out.println(" 4 - Mostrar todos los contactos");
        System.out.println(" 5 - Salir");

        try {
            opc = sc.nextInt();
            opc2 = sc.nextInt();

        } catch (Exception e) {
            System.out.println("Utilizar solo numeros para las opciones");
        }

        while (opc >= 0 && opc <= 5) {
            switch (opc) {

                case 1:
                    System.out.println("Seleccione 1 para añadir un contacto persona o 2 para un contacto empresa");
                    opc2 = sc.nextInt();

                    if (opc2 == 1) {
                        System.out.println(" Se ingresara un contacto persona");

                        System.out.println("Ingrese nombre: ");
                        nombreCompleto = sc.next();
                        System.out.println("Ingrese email: ");
                        email = sc.next();
                        System.out.println("Ingrese telefono celular: ");
                        telefonoCelular = sc.next();
                        System.out.println("Ingrese el DNI: ");
                        dni = sc.next();
                        System.out.println("Telefono: "+marca+" \nPrecio: "+precio+"\nModelo: "+modelo+"\nColor: "+color);

                        agenda[indice] = new Persona(email, telefonoCelular, dni, nombreCompleto);
                        indice++;
                    }

                    if (opc2 == 2) {
                        System.out.println(" Se ingresara un contacto empresa");
                   

                    System.out.println("Ingrese nombre: ");
                    nombreCompleto = sc.next();
                    System.out.println("Ingrese telefono fijo: ");
                    telefonoFijo = sc.next();
                    System.out.println("Ingrese la pagina web: ");
                    webSite = sc.next();
                    System.out.println("Ingrese el CUIT: ");
                    cuit = sc.next();
                   

                    agenda[indice] = new Empresa(telefonoFijo, webSite, cuit, nombreCompleto);
                    indice++;

                    break;

                case 2:
                     System.out.println("Busqueda por ID: ");
                     idb=sc.nextInt();
                     
                       
                           
                    break;
                           

                case 3:
                         System.out.println("Editar contacto: ");
                   break;

                case 4:
                         System.out.println("Mostrar todos los contacto: ");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
                  break; 

                case 5:
                    System.out.println("Finaliza llamada");
                    break;
            }
        }

    }

}
}