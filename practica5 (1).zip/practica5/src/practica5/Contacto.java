/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

abstract public class Contacto {

    String nombreCompleto;
   

    public Contacto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
       
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

       
   abstract void mostrarContacto();
       
   }
