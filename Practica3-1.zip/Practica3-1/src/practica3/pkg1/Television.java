package practica3.pkg1;
public class Television extends DispositivoElectronico implements IFunciones, ICosasTV {

    @Override
    public String encender() {
        return "Television Encendida";
    }

    @Override
    public String apagar() {
        return "Television Apagada";
    }

    @Override
    public String cambioCanal() {
        return "Television puede cambiar de canal";
    }

    @Override
    public String volumen() {
        return "Television con volumen";
    }

    @Override
    public String Color() {
        return "Television Negro";
    }

    @Override
    public String ConfMenu() {
        return "Configuracion del Menu";
    }

    
}
