package practica3.pkg1;
public interface ICosasTV {
    
    public String Color();
    public String ConfMenu();
}