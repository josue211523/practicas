
package practica3.pkg1;


public class Radio extends DispositivoElectronico implements IFunciones{

    @Override
    public String encender() {
        return "Radio Enciende";
    }

    @Override
    public String apagar() {
        return "Radio Apagado";
    }

    @Override
    public String cambioCanal() {
        return "Radio cambia de canal";
    }
   
    public String Color() {
        return "Television Cafe";
    }
    
    @Override
    public String volumen() {
        return "Radio con volumen";
    }
}
    