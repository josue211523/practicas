package practica3.pkg1;

public interface IOperacionesAritmeticas {
    
    public int suma(int a, int b);
    public int resta(int a, int b);
    
    
}