package practica3.pkg1;

public interface IFunciones {
    
    public String cambioCanal();
    public String volumen();
    
}
