package practica3.pkg1;
public class Calculadora extends DispositivoElectronico implements IOperacionesAritmeticas {

    @Override
    public String encender() {
        return "Calculadora encendida";
    }

    @Override
    public String apagar() {
        return "Calculadora apagada";
    }
    public String Color() {
        return "Calculadora Azul";
    }

    @Override
    public int suma(int a, int b) {
        return a+b;
    }

    @Override
    public int resta(int a, int b) {
        return a-b;
    }
    
}